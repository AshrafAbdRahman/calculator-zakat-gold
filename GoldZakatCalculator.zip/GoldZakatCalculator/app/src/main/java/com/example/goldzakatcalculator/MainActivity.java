package com.example.goldzakatcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText goldWeight;
    EditText goldValue;
    RadioButton keep;
    RadioButton wear;
    Button calculate;
    TextView totalZakat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        goldWeight = (EditText) findViewById(R.id.GoldWeight);
        goldValue = (EditText) findViewById(R.id.GoldValue);
        keep = (RadioButton) findViewById(R.id.Keep);
        wear = (RadioButton) findViewById(R.id.Wear);
        calculate = (Button) findViewById(R.id.Calculate);
        totalZakat = (TextView) findViewById(R.id.TotalZakat);

        calculate.setOnClickListener(this);


    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;

    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.ic_menu_edit) {

            Intent intent = new Intent(MainActivity.this, Calculator.class);
            startActivity(intent);

            return true;
        } else if (id == R.id.ic_dialog_info) {

            Intent intent = new Intent(MainActivity.this, About.class);
            startActivity(intent);

            return true;
        } else if (id == R.id.ic_menu_preferences) {

            Intent intent = new Intent(MainActivity.this, Setting.class);
            startActivity(intent);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onRadioButtonClicked(View view, double minus) {
        boolean checked = ((RadioButton) view).isChecked();
        double weight = Double.parseDouble(goldWeight.getText().toString());

        switch (view.getId()) {
            case R.id.Keep:
                if (checked)
                    minus = weight - 85;
                break;
            case R.id.Wear:
                if (checked)
                    minus = weight - 200;
                break;
        }

        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        i.putExtra("my_variable", minus);
        startActivity(i);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            Bundle extras = getIntent().getExtras();
            double minus = 0;
            if (extras != null) {
                minus = Double.parseDouble(extras.getString("my_variable"));
            }

            case R.id.Calculate:
                double value = Double.parseDouble(goldValue.getText().toString());
                double totalZakat = (minus * value) * 0.025;


                break;
        }
    }



}